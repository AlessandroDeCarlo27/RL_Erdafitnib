library(testthat)
library(RsSimulx)

test_check("RsSimulx")
